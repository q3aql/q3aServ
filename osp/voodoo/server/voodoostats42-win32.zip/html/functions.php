<?php


function q3_processColors($str)
{
  $enable_color=1;
  $i=0;
  $ascii=0;

  if ($enable_color)
  	$processed_str="<font color=#FFFFFF>";

  for ($i=0;$i< strlen($str)-1;$i++)
  {
    if ($str[$i]=="^" && $str[$i+1]!="^")
    {

      $ascii = ord($str[$i+1]);

      if ($enable_color)
      {

        // ---------------------------------------------------------
        // Thanks to K9-Moonshine for the OSP rgb color code filter.
        // ---------------------------------------------------------
        // if F,f,B,b,N
      	if ($ascii == 70 || $ascii == 102 || $ascii == 66 || $ascii == 98 || $ascii == 78)
      	{
		  // ignore these codes
		  $i++;
		  continue;
      	}

      	$processed_str .= "</font>";

     	// if ^X
        // actually ideally this would set the background color
        // like it does in Q3. Oh well.
     	if (($ascii == 88 || $ascii == 120) && strlen($str)-$i>6)
        {
		  $processed_str .= "<font color=#";
		  $processed_str .= substr($str, $i+2,6);
		  $processed_str .= ">";
		  $i += 7;
		  continue;
        }
        // ---------------------------------------------------------

      	switch($ascii%8)
      	{
      	  case 0:
      	    $processed_str .= "<font color=#555555>";
      	    break;
      	  case 1:
      	    $processed_str .= "<font color=#FF0000>";
      	    break;
      	  case 2:
      	    $processed_str .= "<font color=#00FF00>";
      	    break;
      	  case 3:
      	    $processed_str .= "<font color=#FFFF00>";
      	    break;
      	  case 4:
      	    $processed_str .= "<font color=#4444FF>";
      	    break;
      	  case 5:
      	    $processed_str .= "<font color=#00FFFF>";
      	    break;
      	  case 6:
      	    $processed_str .= "<font color=#FF00FF>";
      	    break;
      	  case 7:
      	    $processed_str .= "<font color=#FFFFFF>";
      	    break;
      	}
      }
      $i++;
    }
    else
    {
      $processed_str .=$str[$i];
    }
  }
  $processed_str .= $str[$i];
  if ($enable_color)
    $processed_str .= "</font>";
  return $processed_str;
}

// detect_browser() code ripped off Kevin Thompson from php.net support forum.
global $HTTP_USER_AGENT, $BName, $BVersion, $BPlatform;
function detect_browser()
{
	global $HTTP_USER_AGENT, $BName, $BVersion, $BPlatform;

	// Browser
	if(eregi("(opera) ([0-9]{1,2}.[0-9]{1,3}){0,1}",$HTTP_USER_AGENT,$match) || eregi("(opera/)([0-9]{1,2}.[0-9]{1,3}){0,1}",$HTTP_USER_AGENT,$match))
	{
	$BName = "Opera"; $BVersion=$match[2];
	}
	elseif(eregi("(konqueror)/([0-9]{1,2}.[0-9]{1,3})",$HTTP_USER_AGENT,$match))
	{
	$BName = "Konqueror"; $BVersion=$match[2];
	}
	elseif(eregi("(lynx)/([0-9]{1,2}.[0-9]{1,2}.[0-9]{1,2})",$HTTP_USER_AGENT,$match))
	{
	$BName = "Lynx "; $BVersion=$match[2];
	}
	elseif(eregi("(links) \(([0-9]{1,2}.[0-9]{1,3})",$HTTP_USER_AGENT,$match))
	{
	$BName = "Links "; $BVersion=$match[2];
	}
	elseif(eregi("(msie) ([0-9]{1,2}.[0-9]{1,3})",$HTTP_USER_AGENT,$match))
	{
	$BName = "MSIE "; $BVersion=$match[2];
	}
	elseif(eregi("(netscape6)/(6.[0-9]{1,3})",$HTTP_USER_AGENT,$match))
	{
	$BName = "Netscape "; $BVersion=$match[2];
	}
	elseif(eregi("mozilla/5",$HTTP_USER_AGENT))
	{
	$BName = "Mozilla"; $BVersion="5";
	}
	elseif(eregi("(mozilla)/([0-9]{1,2}.[0-9]{1,3})",$HTTP_USER_AGENT,$match))
	{
	$BName = "Netscape "; $BVersion=$match[2];
	}
	elseif(eregi("w3m",$HTTP_USER_AGENT))
	{
	$BName = "w3m"; $BVersion="Unknown";
	}
	else{$BName = "Unknown"; $BVersion="Unknown";}

	// System
	if(eregi("linux",$HTTP_USER_AGENT))
	{
	$BPlatform = "Linux";
	}
	elseif(eregi("win32",$HTTP_USER_AGENT))
	{
	$BPlatform = "Windows";
	}
	elseif((eregi("(win)([0-9]{2})",$HTTP_USER_AGENT,$match)) || (eregi("(windows) ([0-9]{2})",$HTTP_USER_AGENT,$match)))
	{
	$BPlatform = "Windows $match[2]";
	}
	elseif(eregi("(winnt)([0-9]{1,2}.[0-9]{1,2}){0,1}",$HTTP_USER_AGENT,$match))
	{
	$BPlatform = "Windows NT $match[2]";
	}
	elseif(eregi("(windows nt)( ){0,1}([0-9]{1,2}.[0-9]{1,2}){0,1}",$HTTP_USER_AGENT,$match))
	{
	$BPlatform = "Windows NT $match[3]";
	}
	elseif(eregi("mac",$HTTP_USER_AGENT))
	{
	$BPlatform = "Macintosh";
	}
	elseif(eregi("(sunos) ([0-9]{1,2}.[0-9]{1,2}){0,1}",$HTTP_USER_AGENT,$match))
	{
	$BPlatform = "SunOS $match[2]";
	}
	elseif(eregi("(beos) r([0-9]{1,2}.[0-9]{1,2}){0,1}",$HTTP_USER_AGENT,$match))
	{
	$BPlatform = "BeOS $match[2]";
	}
	elseif(eregi("freebsd",$HTTP_USER_AGENT))
	{
	$BPlatform = "FreeBSD";
	}
	elseif(eregi("openbsd",$HTTP_USER_AGENT))
	{
	$BPlatform = "OpenBSD";
	}
	elseif(eregi("irix",$HTTP_USER_AGENT))
	{
	$BPlatform = "IRIX";
	}
	elseif(eregi("os/2",$HTTP_USER_AGENT))
	{
	$BPlatform = "OS/2";
	}
	elseif(eregi("plan9",$HTTP_USER_AGENT))
	{
	$BPlatform = "Plan9";
	}
	elseif(eregi("unix",$HTTP_USER_AGENT) || eregi("hp-ux",$HTTP_USER_AGENT))
	{
	$BPlatform = "Unix";
	}
	elseif(eregi("osf",$HTTP_USER_AGENT))
	{
	$BPlatform = "OSF";
	}
	else{$BPlatform = "Unknown";}

}











?>
