<?php

// database settings
$db_host = "localhost";
$db_name = "voodoostats";
$db_user = "myrddin";
$db_pass = "xxxxxxx";

// display settings
$stylesheet = "s-avalanche.css";
$records_per_page = 50;

// server info
$server_image = "\"images/logo-vp.gif\"";
$server_name  = "magic people voodoo people";

$server_line1 = "moderated by myrddin";
$server_line2 = "ctf";
$server_line3 = "\" feel da jungle vibe bebe \"";

?>