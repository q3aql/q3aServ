<?php

if (!isset($config))
	die("Config file not specified");

require("./$config");
require("./functions.php");

if (!isset($style_table))
	$style_table="";

$db = mysql_connect($db_host, $db_user, $db_pass) or die("<font color=red>Could not connect to database...</font>");
mysql_select_db($db_name,$db);

//******************************************************************************
//* Stat conditions required to appear on table
//******************************************************************************
$result=mysql_query("select STD(games) from playerstats;",$db);
$myrow = mysql_fetch_array($result);
$avg_games = $myrow[0];
//echo $avg_games;
$min_games = $avg_games;
$min_stat = "(skill/games>1 AND games>$min_games)";
//echo $min_games;
$min_stat="games>0";
//******************************************************************************

printf("<html>\n");
printf("<HEAD>\n");
printf("<TITLE>voodoo stats (clan stats)</TITLE>\n");
printf("<LINK REL=stylesheet HREF=\"$stylesheet\" TYPE=\"text/css\">\n");
printf("</HEAD>");

printf("<body onload=\"self.focus();\">\n");

if (!isset($sort_by)) {
	$sort_by="skill";
}
//-----------------------------------------------------
if ($sort_by=="skill") {
	$sort_by_sql="(skill/(games+$avg_games))";
}
else if ($sort_by=="combat") {
	$sort_by_sql="(combat/(games+$avg_games))";
}
else if ($sort_by=="efficiency") {
	$sort_by_sql="((kills*100)/(1+kills+deaths+suicides))";
}
else if ($sort_by=="games") {
	$sort_by_sql="games";
}
else if ($sort_by=="frags") {
	$sort_by_sql="frags";
}
else if ($sort_by=="kills") {
	$sort_by_sql="kills";
}
else if ($sort_by=="deaths") {
	$sort_by_sql="deaths";
}
else if ($sort_by=="suicides") {
	$sort_by_sql="suicides";
}
//-----------------------------------------------------




printf("<table CELLSPACING=0 CELLPADDING=2 WIDTH=100%%>\n");
printf("<tr ><td  CLASS=\"cellHeading\" style=\"text-align: left\" vstyle=\"text-align: center\">Clan profile</div></td></tr>");
printf("<tr ><td  CLASS=\"cell1\" style=\"text-align: center\"><font size=+2>%s</font></td></tr>",q3_processColors($tag));
printf("</table>");

printf("<BR>\n");

printf("<table BORDER=1 CELLSPACING=0 CELLPADDING=2 WIDTH=100%%>\n");
printf("<tr>");

printf("<td CLASS=\"cellHeading\" >#</td>");
printf("<td CLASS=\"cellHeading\"style=\"text-align: left\">Name</td>");
printf("<td CLASS=\"cellHeading\">&nbsp;&nbsp;&nbsp;&nbsp;<A HREF=\"$PHP_SELF?config=$config&tag=$tag&sort_by=skill\"     >Skill :</A></td>");
printf("<td CLASS=\"cellHeading\"><A HREF=\"$PHP_SELF?config=$config&tag=$tag&sort_by=combat\"    >Combat :</td>");
printf("<td CLASS=\"cellHeading\"><A HREF=\"$PHP_SELF?config=$config&tag=$tag&sort_by=frags\"     >Score</A></td>");
printf("<td CLASS=\"cellHeading\">&nbsp;&nbsp;&nbsp;&nbsp;<A HREF=\"$PHP_SELF?config=$config&tag=$tag&sort_by=kills\"     >Kills</A></td>");
printf("<td CLASS=\"cellHeading\"><A HREF=\"$PHP_SELF?config=$config&tag=$tag&sort_by=deaths\"    >Deaths</A></td>");
printf("<td CLASS=\"cellHeading\"><A HREF=\"$PHP_SELF?config=$config&tag=$tag&sort_by=suicides\"  >Suicides</A></td>");
printf("<td CLASS=\"cellHeading\"><A HREF=\"$PHP_SELF?config=$config&tag=$tag&sort_by=efficiency\">Eff.&nbsp;%%</A></td>");
printf("<td CLASS=\"cellHeading\"><A HREF=\"$PHP_SELF?config=$config&tag=$tag&sort_by=games\"     >Games</A></td>");
printf("</tr>\n");


$query_main="SELECT * FROM playerstats WHERE (BINARY raw_name like '%$tag%') AND $min_stat ORDER BY $sort_by_sql DESC LIMIT $records_per_page;";
//echo $query_main;

$result = mysql_query($query_main,$db);
//echo $query_main;
$myrow = mysql_fetch_array($result);
$count = 0;

while ($myrow)
{
	if ($count%2 == 0)
	{
		$cell_class= "cell1";
	}
	else
	{
		$cell_class= "cell2";
	}
	$count++;
	
	
	printf("<tr CLASS=\"$cell_class\" onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='rowNormal';\" >");
	printf("<td CLASS=\"$cell_class\">%d</td>", $count );

	//if ($myrow["skill"]==0.0)
	//	continue;

	$raw_name = $myrow["raw_name"];
	printf("<td CLASS=\"$cell_class\"><DIV style=\"text-align: left\">");

	printf( "<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=%s\" TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">",$raw_name);
	printf("&nbsp;%s",q3_processColors($myrow["raw_name"]));
	
	printf("</A></DIV></td>");
	printf("<td CLASS=\"$cell_class\">%0.2f</td>", $myrow["skill"]/($myrow["games"]+$avg_games));
	printf("<td CLASS=\"$cell_class\">%0.2f</td>", $myrow["combat"]/($myrow["games"]+$avg_games));
	printf("<td CLASS=\"$cell_class\">%d</td>", $myrow["frags"]);
	printf("<td CLASS=\"$cell_class\">%d</td>", $myrow["kills"]);
	printf("<td CLASS=\"$cell_class\">%d</td>", $myrow["deaths"]);
	printf("<td CLASS=\"$cell_class\">%d</td>", $myrow["suicides"]);
	printf("<td CLASS=\"$cell_class\">%0.2f</td>", ($myrow["kills"]*100)/($myrow["kills"]+$myrow["deaths"]+$myrow["suicides"]));
	printf("<td CLASS=\"$cell_class\">%d</td>", $myrow["games"]);
	printf("</tr>\n");
	$myrow = mysql_fetch_array($result);

} 

printf("</table>");

printf("</body>");

printf("</HEAD>");
printf("</html>");


?>

