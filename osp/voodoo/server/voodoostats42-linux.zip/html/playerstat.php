<?php

if (!isset($config))
	die("Config file not specified");

require("./$config");
require("./functions.php");

if (!isset($style_table))
	$style_table="";

$db = mysql_connect($db_host, $db_user, $db_pass) or die("<font color=red>Could not connect to database...</font>");
mysql_select_db($db_name,$db);

$result=mysql_query("select STD(games) from playerstats;",$db);
$myrow = mysql_fetch_array($result);
$avg_games = $myrow[0];

printf("<html>\n");
printf("<HEAD>\n");
printf("<TITLE>voodoo stats (player stats)</TITLE>\n");
printf("<LINK REL=stylesheet HREF=\"$stylesheet\" TYPE=\"text/css\">\n");
printf("<script language=\"JavaScript\">");
printf("function loadDefaultModel()\n");
printf("{ document.MODEL.src=\"images/models/sarge/pic.jpg\"; }\n");
printf("</script>");

printf("</HEAD>");
printf("<body onload=\"self.focus();\">\n");


$query = "SELECT * FROM playerstats WHERE raw_name=\"$raw_name\" LIMIT 1";

$result = mysql_query($query,$db);
$myrow = mysql_fetch_array($result);



printf("<table style=\"border-width: 1\" CELLSPACING=0 CELLPADDING=2 WIDTH=100%%>\n");
printf("<tr ><td CLASS=\"cellHeading\" COLSPAN=2 style=\"text-align: left\" valign=\"center\">Player profile</td></tr>");
$tmp = "models/" ;
$tmp .= $myrow["model"]; 
$tmp .= "/pic.jpg";
printf("<tr >");
printf("<td CLASS=\"cell1\" valign=\"center\" style=\"text-align: center\"><IMAGE NAME=MODEL SRC=\"images/$tmp\" onError=\"loadDefaultModel()\"></td><td CLASS=\"cell1\" WIDTH=100%% VALIGN=TOP><font size=+1>%s</font><br><br><br>\" %s \"</td>",q3_processColors($myrow["raw_name"]),$myrow["quote"]);
printf("</tr>");
printf("</table>");


printf("<br>");

printf("<table BORDER=0 CELLSPACING=0 CELLPADDING=3 WIDTH=100%% >\n");
printf("<tr>");

printf("<td style=\"border-width: 0\" WIDTH=25%% ALIGN=CENTER VALIGN=TOP >");

printf("<table style=\"border-width: 1\" CELLSPACING=0 CELLPADDING=2 WIDTH=100%% >\n");
printf("<tr >                                                                                        <td CLASS=\"cellHeading\" style=\"text-align: left  \">&nbsp;Main stats</td>           <td CLASS=\"cellHeading\" style=\"text-align: center\">total</td></tr>");
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell2';\" ><td CLASS=\"cell2\" style=\"text-align: left  \">&nbsp;Games Played</td>               <td CLASS=\"cell2\" style=\"text-align: center\">%d</td></tr>", 	        $myrow["games"]);
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell1';\" ><td CLASS=\"cell1\" style=\"text-align: left  \">&nbsp;Skill :</td>                    <td CLASS=\"cell1\" style=\"text-align: center\">%0.2f</td></tr>",        $myrow["skill"]/($myrow["games"]+$avg_games));
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell2';\" ><td CLASS=\"cell2\" style=\"text-align: left  \">&nbsp;Combat :</td>                   <td CLASS=\"cell2\" style=\"text-align: center\">%0.2f</td></tr>",        $myrow["combat"]/($myrow["games"]+$avg_games));
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell1';\" ><td CLASS=\"cell1\" style=\"text-align: left  \">&nbsp;Damage Given</td>               <td CLASS=\"cell1\" style=\"text-align: center\">%d</td></tr>", 	        $myrow["damage_given"]);
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell2';\" ><td CLASS=\"cell2\" style=\"text-align: left  \">&nbsp;Damage Received</td>            <td CLASS=\"cell2\" style=\"text-align: center\">%d</td></tr>",           $myrow["damage_recvd"]);
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell1';\" ><td CLASS=\"cell1\" style=\"text-align: left  \">&nbsp;Score</td>                      <td CLASS=\"cell1\" style=\"text-align: center\">%d</td></tr>",           $myrow["frags"]);
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell2';\" ><td CLASS=\"cell2\" style=\"text-align: left  \">&nbsp;Kills</td>                      <td CLASS=\"cell2\" style=\"text-align: center\">%d</td></tr>",           $myrow["kills"]);
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell1';\" ><td CLASS=\"cell1\" style=\"text-align: left  \">&nbsp;Deaths</td>                     <td CLASS=\"cell1\" style=\"text-align: center\">%d</td></tr>",           $myrow["deaths"]);
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell2';\" ><td CLASS=\"cell2\" style=\"text-align: left  \">&nbsp;Suicides / Team Kills</td>      <td CLASS=\"cell2\" style=\"text-align: center\">%d / %d</td></tr>",      $myrow["suicides"],$myrow["team_kills"]);
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell1';\" ><td CLASS=\"cell1\" style=\"text-align: left  \">&nbsp;Streak, Kills / Deaths</td>     <td CLASS=\"cell1\" style=\"text-align: center\">%d / %d</td></tr>", 	    $myrow["kill_streak"],$myrow["death_streak"]);

printf("</table>");

printf("</td>");



printf("<td style=\"border-width: 0\" WIDTH=50%% ALIGN=CENTER VALIGN=TOP >");

printf("<table style=\"$style_table\" style=\"border-width: 1\" CELLSPACING=0 CELLPADDING=2 WIDTH=100%% >\n");
printf("<tr  >                                                                                       <td CLASS=\"cellHeading\" >acc.%%</td>  <td CLASS=\"cellHeading\" >hits</td>                 <td  CLASS=\"cellHeading\" style=\"text-align: left\">fired</td>                   <td  CLASS=\"cellHeading\" WIDTH=100 style=\"text-align: center\">Weapon stats</td>         <td CLASS=\"cellHeading\" >kills</td>             <td CLASS=\"cellHeading\" style=\"text-align: left\">deaths</td>        <td CLASS=\"cellHeading\" >eff.%%</td></tr>");
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell1';\" ><td CLASS=\"cell1\" >-</td>             <td CLASS=\"cell1\" >-</td>                          <td  CLASS=\"cell1\" style=\"text-align: left\">-</td>                             <td  CLASS=\"cell1\" style=\"text-align: center\">gauntlet</td>                             <td CLASS=\"cell1\" >$myrow[kills_G]</td>   <td  CLASS=\"cell1\" style=\"text-align: left\">$myrow[deaths_G]</td>   <td CLASS=\"cell1\" >%0.2lf</td></tr>",                                                                                     $myrow["kills_G"]  /(0.001 + $myrow["kills_G"]   + $myrow["deaths_G"])  *100 );
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell2';\" ><td CLASS=\"cell2\" >%0.2lf</td>        <td CLASS=\"cell2\" >$myrow[accuracy_MG_hits]</td>   <td  CLASS=\"cell2\" style=\"text-align: left\">$myrow[accuracy_MG_attempts]</td>  <td  CLASS=\"cell2\" style=\"text-align: center\">machine gun</td>                          <td CLASS=\"cell2\" >$myrow[kills_MG]</td>  <td  CLASS=\"cell2\" style=\"text-align: left\">$myrow[deaths_MG]</td>  <td CLASS=\"cell2\" >%0.2lf</td></tr>", 		   $myrow["accuracy_MG_hits"] /($myrow["accuracy_MG_attempts"] +0.1) *100 , $myrow["kills_MG"] /(0.001 + $myrow["kills_MG"]  + $myrow["deaths_MG"]) *100 );
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell1';\" ><td CLASS=\"cell1\" >%0.2lf</td>        <td CLASS=\"cell1\" >$myrow[accuracy_SG_hits]</td>   <td  CLASS=\"cell1\" style=\"text-align: left\">$myrow[accuracy_SG_attempts]</td>  <td  CLASS=\"cell1\" style=\"text-align: center\">shot gun</td>                             <td CLASS=\"cell1\" >$myrow[kills_SG]</td>  <td  CLASS=\"cell1\" style=\"text-align: left\">$myrow[deaths_SG]</td>  <td CLASS=\"cell1\" >%0.2lf</td></tr>", 		   $myrow["accuracy_SG_hits"] /($myrow["accuracy_SG_attempts"] +0.1) *100 , $myrow["kills_SG"] /(0.001 + $myrow["kills_SG"]  + $myrow["deaths_SG"]) *100 );
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell2';\" ><td CLASS=\"cell2\" >%0.2lf</td>        <td CLASS=\"cell2\" >$myrow[accuracy_GL_hits]</td>   <td  CLASS=\"cell2\" style=\"text-align: left\">$myrow[accuracy_GL_attempts]</td>  <td  CLASS=\"cell2\" style=\"text-align: center\">grenade</td>                              <td CLASS=\"cell2\" >$myrow[kills_GL]</td>  <td  CLASS=\"cell2\" style=\"text-align: left\">$myrow[deaths_GL]</td>  <td CLASS=\"cell2\" >%0.2lf</td></tr>", 		   $myrow["accuracy_GL_hits"] /($myrow["accuracy_GL_attempts"] +0.1) *100 , $myrow["kills_GL"] /(0.001 + $myrow["kills_GL"]  + $myrow["deaths_GL"]) *100 );
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell1';\" ><td CLASS=\"cell1\" >%0.2lf</td>        <td CLASS=\"cell1\" >$myrow[accuracy_RL_hits]</td>   <td  CLASS=\"cell1\" style=\"text-align: left\">$myrow[accuracy_RL_attempts]</td>  <td  CLASS=\"cell1\" style=\"text-align: center\">rocket launcher</td>                      <td CLASS=\"cell1\" >$myrow[kills_RL]</td>  <td  CLASS=\"cell1\" style=\"text-align: left\">$myrow[deaths_RL]</td>  <td CLASS=\"cell1\" >%0.2lf</td></tr>", 		   $myrow["accuracy_RL_hits"] /($myrow["accuracy_RL_attempts"] +0.1) *100 , $myrow["kills_RL"] /(0.001 + $myrow["kills_RL"]  + $myrow["deaths_RL"]) *100 );
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell2';\" ><td CLASS=\"cell2\" >%0.2lf</td>        <td CLASS=\"cell2\" >$myrow[accuracy_LG_hits]</td>   <td  CLASS=\"cell2\" style=\"text-align: left\">$myrow[accuracy_LG_attempts]</td>  <td  CLASS=\"cell2\" style=\"text-align: center\">lightning gun</td>                        <td CLASS=\"cell2\" >$myrow[kills_LG]</td>  <td  CLASS=\"cell2\" style=\"text-align: left\">$myrow[deaths_LG]</td>  <td CLASS=\"cell2\" >%0.2lf</td></tr>", 		   $myrow["accuracy_LG_hits"] /($myrow["accuracy_LG_attempts"] +0.1) *100 , $myrow["kills_LG"] /(0.001 + $myrow["kills_LG"]  + $myrow["deaths_LG"]) *100 );
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell1';\" ><td CLASS=\"cell1\" >%0.2lf</td>        <td CLASS=\"cell1\" >$myrow[accuracy_RG_hits]</td>   <td  CLASS=\"cell1\" style=\"text-align: left\">$myrow[accuracy_RG_attempts]</td>  <td  CLASS=\"cell1\" style=\"text-align: center\">rail gun</td>                             <td CLASS=\"cell1\" >$myrow[kills_RG]</td>  <td  CLASS=\"cell1\" style=\"text-align: left\">$myrow[deaths_RG]</td>  <td CLASS=\"cell1\" >%0.2lf</td></tr>", 		   $myrow["accuracy_RG_hits"] /($myrow["accuracy_RG_attempts"] +0.1) *100 , $myrow["kills_RG"] /(0.001 + $myrow["kills_RG"]  + $myrow["deaths_RG"]) *100 );
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell2';\" ><td CLASS=\"cell2\" >%0.2lf</td>        <td CLASS=\"cell2\" >$myrow[accuracy_PG_hits]</td>   <td  CLASS=\"cell2\" style=\"text-align: left\">$myrow[accuracy_PG_attempts]</td>  <td  CLASS=\"cell2\" style=\"text-align: center\">plasma gun</td>                           <td CLASS=\"cell2\" >$myrow[kills_PG]</td>  <td  CLASS=\"cell2\" style=\"text-align: left\">$myrow[deaths_PG]</td>  <td CLASS=\"cell2\" >%0.2lf</td></tr>", 		   $myrow["accuracy_PG_hits"] /($myrow["accuracy_PG_attempts"] +0.1) *100 , $myrow["kills_PG"] /(0.001 + $myrow["kills_PG"]  + $myrow["deaths_PG"]) *100 );
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell1';\" ><td CLASS=\"cell1\" >%0.2lf</td>        <td CLASS=\"cell1\" >$myrow[accuracy_BFG_hits]</td>  <td  CLASS=\"cell1\" style=\"text-align: left\">$myrow[accuracy_BFG_attempts]</td> <td  CLASS=\"cell1\" style=\"text-align: center\">bfg</td>                                  <td CLASS=\"cell1\" >$myrow[kills_BFG]</td> <td  CLASS=\"cell1\" style=\"text-align: left\">$myrow[deaths_BFG]</td> <td CLASS=\"cell1\" >%0.2lf</td></tr>", 	       $myrow["accuracy_BFG_hits"]/($myrow["accuracy_BFG_attempts"]+0.1) *100 , $myrow["kills_BFG"]/(0.001 + $myrow["kills_BFG"] + $myrow["deaths_BFG"])*100 );
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell2';\" ><td CLASS=\"cell2\" >-</td>             <td CLASS=\"cell2\" >-</td>                          <td  CLASS=\"cell2\" style=\"text-align: left\">-</td>                             <td  CLASS=\"cell2\" style=\"text-align: center\">telefrag</td>                             <td CLASS=\"cell2\" >$myrow[kills_TF]</td>  <td  CLASS=\"cell2\" style=\"text-align: left\">$myrow[deaths_TF]</td>  <td CLASS=\"cell2\" >%0.2lf</td></tr>", 		                                                                            $myrow["kills_TF"] /(0.001 + $myrow["kills_TF"]  + $myrow["deaths_TF"]) *100 );
printf("</table>");

printf("</td>");



printf("<td style=\"border-width: 0\" WIDTH=25%% ALIGN=CENTER VALIGN=TOP >");

printf("<table style=\"border-width: 1\" CELLSPACING=0 CELLPADDING=2 WIDTH=100%% >\n");
printf("<tr >                                                                                        <td  CLASS=\"cellHeading\" style=\"text-align: left\">&nbsp;CTF stats</td><td  CLASS=\"cellHeading\" style=\"text-align: center\">total</td></tr>");
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell2';\" ><td  CLASS=\"cell2\" style=\"text-align: left\">&nbsp;Flag captures</td>                   <td CLASS=\"cell2\" style=\"text-align: center\">%d</td></tr>", 		$myrow["ctf_flag_caps"]);
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell1';\" ><td  CLASS=\"cell1\" style=\"text-align: left\">&nbsp;Flag touches</td>                    <td CLASS=\"cell1\" style=\"text-align: center\">%d</td></tr>", 		$myrow["ctf_flag_touches"]);
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell2';\" ><td  CLASS=\"cell2\" style=\"text-align: left\">&nbsp;Flag hold kills</td>                 <td CLASS=\"cell2\" style=\"text-align: center\">%d</td></tr>", 		$myrow["ctf_flag_hold_kills"]);
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell1';\" ><td  CLASS=\"cell1\" style=\"text-align: left\">&nbsp;FC defends</td>                      <td CLASS=\"cell1\" style=\"text-align: center\">%d</td></tr>", 		$myrow["ctf_fc_defends"]);
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell2';\" ><td  CLASS=\"cell2\" style=\"text-align: left\">&nbsp;FC defends agressive</td>            <td CLASS=\"cell2\" style=\"text-align: center\">%d</td></tr>",       $myrow["ctf_fc_defends_aggressive"]);
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell1';\" ><td  CLASS=\"cell1\" style=\"text-align: left\">&nbsp;Base defends</td>                    <td CLASS=\"cell1\" style=\"text-align: center\">%d</td></tr>", 		$myrow["ctf_base_defends"]);
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell2';\" ><td  CLASS=\"cell2\" style=\"text-align: left\">&nbsp;EFC kills</td>                       <td CLASS=\"cell2\" style=\"text-align: center\">%d</td></tr>", 		$myrow["ctf_efc_kills"]);
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell1';\" ><td  CLASS=\"cell1\" style=\"text-align: left\">&nbsp;Flag returns</td>                    <td CLASS=\"cell1\" style=\"text-align: center\">%d</td></tr>", 		$myrow["ctf_flag_returns"]);
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell2';\" ><td  CLASS=\"cell2\" style=\"text-align: left\">&nbsp;Capture assist kills</td>            <td CLASS=\"cell2\" style=\"text-align: center\">%d</td></tr>", 		$myrow["ctf_assist_efc_kills"]);
printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell1';\" ><td  CLASS=\"cell1\" style=\"text-align: left\">&nbsp;Capture assist returns</td>          <td CLASS=\"cell1\" style=\"text-align: center\">%d</td></tr>", 		$myrow["ctf_assist_flag_returns"]);
printf("</table>");

printf("</td>");

printf("</tr>");
printf("</table>");


printf("<BR>");

printf("<table style=\"$style_table\" style=\"border-width: 1\" CELLSPACING=0 CELLPADDING=2 WIDTH=100%% >\n");
printf("<tr >");
printf("<td CLASS=\"cellHeading\" style=\"text-align: center\">quad</td>");
printf("<td CLASS=\"cellHeading\" style=\"text-align: center\">haste</td>");
printf("<td CLASS=\"cellHeading\" style=\"text-align: center\">regen</td>");
printf("<td CLASS=\"cellHeading\" style=\"text-align: center\">mega</td>");
printf("<td CLASS=\"cellHeading\" style=\"text-align: center\">r.a.</td>");
printf("<td CLASS=\"cellHeading\" style=\"text-align: center\">y.a.</td>");
printf("</tr>");

printf("<tr onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='cell1';\" >");
printf("<td CLASS=\"cell1\" style=\"text-align: center\">$myrow[item_quad]</td>");
printf("<td CLASS=\"cell2\" style=\"text-align: center\">$myrow[item_haste]</td>");
printf("<td CLASS=\"cell1\" style=\"text-align: center\">$myrow[item_regen]</td>");
printf("<td CLASS=\"cell2\" style=\"text-align: center\">$myrow[item_mega]</td>");
printf("<td CLASS=\"cell1\" style=\"text-align: center\">$myrow[item_ra]</td>");
printf("<td CLASS=\"cell2\" style=\"text-align: center\">$myrow[item_ya]</td>");
printf("</tr>");
printf("</table>");



printf("</body>");

printf("</HEAD>");
printf("</html>");


?>

