<?php


//******************************************************************************
//* Default Settings
//******************************************************************************
if (!isset($config))
	$config = "cfg-default.php";
//******************************************************************************

require($config);
require("./functions.php");

printf("<html>");
printf("<HEAD>");
printf("<TITLE>voodoo stats by myrdd1n@hotmail.com & r3act@hotmail.com</TITLE>");
printf("<LINK REL=stylesheet HREF=\"$stylesheet\" TYPE=\"text/css\">");
printf("</HEAD>");
printf("<body>\n");

//******************************************************************************
// Stuff for browser compatiblity (ghey)
// CSS2 is only supported in IE 5.0 and up and Netscape 6.0 and up so far.
// The page wont display as intended on Netscape 4.xx and below or on any other
// browser that doesnt have proper support for CSS including inline CSS and CLASS.
//******************************************************************************
detect_browser();
//echo "$HTTP_USER_AGENT<br>";
//echo "$BName<br>";
//echo "$BVersion<br>";
//echo "$BPlatform<br>";
//echo getenv("REMOTE_ADDR");
if ( (strstr($BName,"MSIE") && (float) $BVersion < 5.0 ) ||
     (strstr($BName,"Netscape") && (float) $BVersion < 6.0 )
   )
{
	//printf("<center>");
	//printf("<BR><B>Warning!<BR>The page may not display as intended on your browser. It may look fugly!<BR>Your browser - $BName $BVersion</B><BR>");
	//printf("<BR>Get the latest Mozilla (open source web browser) to view this page properly!<BR><A HREF=\"http://www.mozilla.org/\">download mozilla</A><BR>");
	//printf("<BR>You need Internet Explorer 5.0 or above to view this page properly!<BR><A HREF=\"http://www.microsoft.com/ie/\">download internet explorer</A><BR>");
	//printf("<BR>You need Netscape 6.0 or above to view this page properly!<BR><A HREF=\"http://www.netscape.com\">download netscape</A><BR>");
	//printf("<BR></center>");
}
if (
	(!strstr($BPlatform,"Macintosh") && strstr($BName,"MSIE") && (float) $BVersion >= 5.0 ) ||
	(strstr($BName,"Netscape") && (float) $BVersion >= 6.0 ) ||
	(strstr($BName,"Opera") && (float) $BVersion >= 4.02 ) ||
	(strstr($BName,"Mozilla"))
	)
{
	$style_table="table-layout: fixed";
	//echo "css2 enabled<br>";
}
else
{
	$style_table="NULL";
	//echo "not loading css2<br>";
}
//******************************************************************************



$db = mysql_connect($db_host, $db_user, $db_pass) or die("<font color=red>Could not connect to database...</font>");
mysql_select_db($db_name,$db);

$result=mysql_query("select STD(games) from playerstats;",$db);
$myrow = mysql_fetch_array($result);
$avg_games = $myrow[0];
//echo $avg_games;

//******************************************************************************
//* Stat conditions required to appear on table
//******************************************************************************
//$min_stat = "(games>$avg_games)";
$min_stat = "games>0";
//******************************************************************************



//-----------------------------------------------------
if (isset($goto_btn)||isset($goto_txt)) {
	$start_from=$goto_txt-1;
}

if (!isset($start_from)) {
    $start_from=0;
}

if (!isset($sort_by)) {
	$sort_by="skill";
}
//-----------------------------------------------------
if ($sort_by=="skill") {
	$sort_by_sql="(skill/(games+$avg_games))";
}
else if ($sort_by=="combat") {
	$sort_by_sql="(combat/(games+$avg_games))";
}
else if ($sort_by=="efficiency") {
	$sort_by_sql="((kills*100)/(1+kills+deaths+suicides))";
}
else if ($sort_by=="games") {
	$sort_by_sql="games";
}
else if ($sort_by=="frags") {
	$sort_by_sql="frags";
}
else if ($sort_by=="kills") {
	$sort_by_sql="kills";
}
else if ($sort_by=="deaths") {
	$sort_by_sql="deaths";
}
else if ($sort_by=="suicides") {
	$sort_by_sql="suicides";
}
//-----------------------------------------------------

$result=mysql_query("select count(*) from playerstats WHERE $min_stat");
$myrow = mysql_fetch_array($result);
$total_records=$myrow[0];

$next=$start_from+$records_per_page;
$prev=$start_from-$records_per_page;

if ($prev<0)
	$prev=0;

if ($next>$total_records)
	$next=$total_records;
//-----------------------------------------------------





//******************************************************************************
//* Title Table - Please leave as it is.
//******************************************************************************
printf("<table CELLSPACING=0 CELLPADDING=2 WIDTH=100%% style=\"border-width: 1\" CLASS=\"cellHeading\">\n");
printf("<tr>");
printf("<td WIDTH=50%% style=\"text-align: left;  border-width: 0\" CLASS=\"cellHeading\">&nbsp;<A HREF=\"http://www.clanavl.com/voodoo/\">voodoo stats</A> &#169; by <A HREF=\"mailto:myrdd1n@hotmail.com\">myrddin</A> & <A HREF=\"mailto:r3act@hotmail.com\">react</A></td>");
printf("<td WIDTH=50%% style=\"text-align: right; border-width: 0\" CLASS=\"cellHeading\"><A HREF=\"http://www.clanavl.com/voodoo/\">www.clanavl.com/voodoo/</A>&nbsp;</td>");
printf("</tr>");
printf("</table>");
printf("<BR>");
//******************************************************************************






//******************************************************************************
// MUST MAKE AWARDS CALCULATION FASTER!
// This is not optimized at all and it shows!
// If anyone can make the award calcuations faster, or any other improvements
// please inform myrdd1n@hotmail.com so it can be included in future releases.
//******************************************************************************
if (!isset($skip_awards) && $start_from==0 && !(isset($search_btn)||isset($search_txt)))
{
//******************************************************************************
//* Player Awards - Regular
//******************************************************************************
mysql_query("select @max:=MAX(skill/(games+$avg_games))-0.01 FROM playerstats WHERE games>$avg_games LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE (skill/(games+$avg_games))>=@max AND games>$avg_games;",$db);
if ($result) {
	$myrow = mysql_fetch_array($result);
	$best_skill= $myrow[0];
}

mysql_query("select @max:=MAX(combat/(games+$avg_games))-0.01 FROM playerstats WHERE games>$avg_games LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE (combat/(games+$avg_games))>=@max AND games>$avg_games;",$db);
if ($result) {
	$myrow = mysql_fetch_array($result);
	$best_combat= $myrow[0];
}

mysql_query("select @max:=MAX(kills/(games+$avg_games))-0.01 FROM playerstats WHERE games>$avg_games LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE (kills/(games+$avg_games))>=@max AND games>$avg_games;",$db);
if ($result) {
	$myrow = mysql_fetch_array($result);
	$best_kills= $myrow[0];
}

mysql_query("select @max:=MAX(kill_streak) FROM playerstats WHERE games>$avg_games AND kill_streak>1 LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE kill_streak=@max AND games>$avg_games;",$db);
if ($result) {
	$myrow = mysql_fetch_array($result);
	$best_kill_streak= $myrow[0];
}

mysql_query("select @max:=MAX(damage_given/(games+$avg_games))-0.01 FROM playerstats WHERE games>$avg_games AND damage_given>1 LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE (damage_given/(games+$avg_games))>=@max AND games>$avg_games;",$db);
if ($result) {
	$myrow = mysql_fetch_array($result);
	$best_damage_given= $myrow[0];
}


$result=mysql_query("select STD(accuracy_total_attempts) from playerstats;",$db);
if ($result) {
	$myrow = mysql_fetch_array($result);
	$avg_accuracy = $myrow[0];
}
//echo $avg_accuracy;
mysql_query("select @max:=MAX(accuracy_total_hits/accuracy_total_attempts)-0.01 FROM playerstats WHERE accuracy_total_attempts>$avg_accuracy LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE accuracy_total_hits/accuracy_total_attempts>=@max AND accuracy_total_attempts>$avg_accuracy;",$db);
if ($result) {
	$myrow = mysql_fetch_array($result);
	$best_accuracy_total= $myrow[0];
}


//******************************************************************************



//******************************************************************************
//* Player Awards - CTF
//******************************************************************************
mysql_query("select @max:=MAX(ctf_flag_caps/(games+$avg_games))-0.01 FROM playerstats WHERE games>$avg_games AND (ctf_flag_caps>0) LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE ctf_flag_caps/(games+$avg_games)>=@max AND (games>$avg_games);",$db);
if ($result) {
	$myrow = mysql_fetch_array($result);
	$best_caps= $myrow[0];
}

mysql_query("select @max:=MAX(ctf_base_defends/(games+$avg_games))-0.01 FROM playerstats WHERE (games>$avg_games) AND ctf_base_defends>0 LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE ctf_base_defends/(games+$avg_games)>=@max AND (games>$avg_games);",$db);
if ($result) {
	$myrow = mysql_fetch_array($result);
	$best_defends= $myrow[0];
}

mysql_query("select @max:=MAX(ctf_flag_hold_kills/(games+$avg_games))-0.01 FROM playerstats WHERE (games>$avg_games) AND ctf_flag_hold_kills>0 LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE ctf_flag_hold_kills/(games+$avg_games)>=@max AND (games>$avg_games);",$db);
if ($result) {
	$myrow = mysql_fetch_array($result);
	$best_holdkills= $myrow[0];
}

mysql_query("select @max:=MAX((ctf_fc_defends+(1.5*ctf_fc_defends_aggressive))/(games+$avg_games))-0.01 FROM playerstats WHERE (games>$avg_games) AND (ctf_fc_defends>0 OR ctf_fc_defends_aggressive>0) LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE (ctf_fc_defends+(1.5*ctf_fc_defends_aggressive))/(games+$avg_games)>=@max AND (games>$avg_games);",$db);
if ($result) {
	$myrow = mysql_fetch_array($result);
	$best_escort= $myrow[0];
}

mysql_query("select @max:=MAX((ctf_flag_returns+(1.5*ctf_efc_kills))/(games+$avg_games))-0.01 FROM playerstats WHERE (games>$avg_games) AND (ctf_flag_returns>0 OR ctf_efc_kills>0) LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE (ctf_flag_returns+(1.5*ctf_efc_kills))/(games+$avg_games)>=@max AND (games>$avg_games);",$db);
if ($result) {
	$myrow = mysql_fetch_array($result);
	$best_chaser= $myrow[0];
}

mysql_query("select @max:=MAX((ctf_assist_flag_returns+(1.5*ctf_assist_efc_kills))/(games+$avg_games))-0.01 FROM playerstats WHERE (games>$avg_games) AND (ctf_assist_flag_returns>0 OR ctf_assist_efc_kills>0) LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE (ctf_assist_flag_returns+(1.5*ctf_assist_efc_kills))/(games+$avg_games)>=@max AND (games>$avg_games);",$db);
if ($result) {
	$myrow = mysql_fetch_array($result);
	$best_assists= $myrow[0];
}

mysql_query("select @max:=MAX(item_haste/(games+$avg_games))-0.01 FROM playerstats WHERE (games>$avg_games) AND (item_haste>0) LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE item_haste/(games+$avg_games)>=@max AND (games>$avg_games);",$db);
if ($result) {
	$myrow = mysql_fetch_array($result);
	$best_haste= $myrow[0];
}

mysql_query("select @max:=MAX(item_regen/(games+$avg_games))-0.01 FROM playerstats WHERE (games>$avg_games) AND (item_regen>0) LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE item_regen/(games+$avg_games)>=@max AND $min_stat;",$db);
if ($result) {
	$myrow = mysql_fetch_array($result);
	$best_regen= $myrow[0];
}

mysql_query("select @max:=MAX(item_quad/(games+$avg_games))-0.01 FROM playerstats WHERE (games>$avg_games) AND (item_quad>0) LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE item_quad/(games+$avg_games)>=@max AND (games>$avg_games);",$db);
if ($result) {
	$myrow = mysql_fetch_array($result);
	$best_quad= $myrow[0];
}

mysql_query("select @max:=MAX(item_mega/(games+$avg_games))-0.01 FROM playerstats WHERE (games>$avg_games) AND (item_mega>0) LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE item_mega/(games+$avg_games)>=@max AND (games>$avg_games);",$db);
if ($result) {
	$myrow = mysql_fetch_array($result);
	$best_mega= $myrow[0];
}

mysql_query("select @max:=MAX(item_ra/(games+$avg_games))-0.01 FROM playerstats WHERE (games>$avg_games) AND (item_ra>0) LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE item_ra/(games+$avg_games)>=@max AND (games>$avg_games);",$db);
if ($result) {
	$myrow = mysql_fetch_array($result);
	$best_ra= $myrow[0];
}

mysql_query("select @max:=MAX(item_ya/(games+$avg_games))-0.01 FROM playerstats WHERE (games>$avg_games) AND (item_ya>0) LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE item_ya/(games+$avg_games)>=@max AND (games>$avg_games);",$db);
if ($result) {
	$myrow = mysql_fetch_array($result);
	$best_ya= $myrow[0];
}

//******************************************************************************


//******************************************************************************
//* Weapon Awards - Accuracy
//******************************************************************************
mysql_query("select @max:=MAX(kills_TF/(games+$avg_games))-0.01 FROM playerstats WHERE (games>$avg_games) LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE kills_TF/(games+$avg_games)>=@max AND (games>$avg_games);",$db);
if ($result) {
	$myrow = mysql_fetch_array($result);
	$best_kills_TF= $myrow[0];
}


$result=mysql_query("select STD(accuracy_MG_attempts) from playerstats;",$db);
$myrow = mysql_fetch_array($result);
$avg_accuracy = $myrow[0];
//echo $avg_accuracy;
mysql_query("select @max:=MAX(accuracy_MG_hits/accuracy_MG_attempts)-0.01 FROM playerstats WHERE accuracy_MG_attempts>$avg_accuracy LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE accuracy_MG_hits    /accuracy_MG_attempts>=@max AND accuracy_MG_attempts>$avg_accuracy;",$db);
if ($result) {
$myrow = mysql_fetch_array($result);
$best_accuracy_MG= $myrow[0];
}

$result=mysql_query("select STD(accuracy_SG_attempts) from playerstats;",$db);
if ($result) {
$myrow = mysql_fetch_array($result);
$avg_accuracy = $myrow[0];
}
//echo $avg_accuracy;

mysql_query("select @max:=MAX(accuracy_SG_hits/accuracy_SG_attempts)-0.01 FROM playerstats WHERE accuracy_SG_attempts>$avg_accuracy LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE accuracy_SG_hits    /accuracy_SG_attempts>=@max AND accuracy_SG_attempts>$avg_accuracy;",$db);
if ($result) {
$myrow = mysql_fetch_array($result);
$best_accuracy_SG= $myrow[0];
}

$result=mysql_query("select STD(accuracy_GL_attempts) from playerstats;",$db);
if ($result) {
$myrow = mysql_fetch_array($result);
$avg_accuracy = $myrow[0];
}
//echo $avg_accuracy;

mysql_query("select @max:=MAX(accuracy_GL_hits/accuracy_GL_attempts)-0.01 FROM playerstats WHERE accuracy_GL_attempts>$avg_accuracy LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE accuracy_GL_hits    /accuracy_GL_attempts>=@max AND accuracy_GL_attempts>$avg_accuracy;",$db);
if ($result) {
$myrow = mysql_fetch_array($result);
$best_accuracy_GL= $myrow[0];
}

$result=mysql_query("select STD(accuracy_RL_attempts) from playerstats;",$db);
if ($result) {
$myrow = mysql_fetch_array($result);
$avg_accuracy = $myrow[0];
}
//echo $avg_accuracy;

mysql_query("select @max:=MAX(accuracy_RL_hits/accuracy_RL_attempts)-0.01 FROM playerstats WHERE accuracy_RL_attempts>$avg_accuracy LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE accuracy_RL_hits    /accuracy_RL_attempts>=@max AND accuracy_RL_attempts>$avg_accuracy;",$db);
if ($result) {
$myrow = mysql_fetch_array($result);
$best_accuracy_RL= $myrow[0];
}

$result=mysql_query("select STD(accuracy_LG_attempts) from playerstats;",$db);
if ($result) {
$myrow = mysql_fetch_array($result);
$avg_accuracy = $myrow[0];
}
//echo $avg_accuracy;

mysql_query("select @max:=MAX(accuracy_LG_hits/accuracy_LG_attempts)-0.01 FROM playerstats WHERE accuracy_LG_attempts>$avg_accuracy LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE accuracy_LG_hits    /accuracy_LG_attempts>=@max AND accuracy_LG_attempts>$avg_accuracy;",$db);
if ($result) {
$myrow = mysql_fetch_array($result);
$best_accuracy_LG= $myrow[0];
}

$result=mysql_query("select STD(accuracy_RG_attempts) from playerstats;",$db);
if ($result) {
$myrow = mysql_fetch_array($result);
$avg_accuracy = $myrow[0];
}
//echo $avg_accuracy;

mysql_query("select @max:=MAX(accuracy_RG_hits/accuracy_RG_attempts)-0.01 FROM playerstats WHERE accuracy_RG_attempts>$avg_accuracy LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE accuracy_RG_hits    /accuracy_RG_attempts>=@max AND accuracy_RG_attempts>$avg_accuracy;",$db);
if ($result) {
$myrow = mysql_fetch_array($result);
$best_accuracy_RG= $myrow[0];
}

$result=mysql_query("select STD(accuracy_PG_attempts) from playerstats;",$db);
if ($result) {
$myrow = mysql_fetch_array($result);
$avg_accuracy = $myrow[0];
}
//echo $avg_accuracy;

mysql_query("select @max:=MAX(accuracy_PG_hits/accuracy_PG_attempts)-0.01 FROM playerstats WHERE accuracy_PG_attempts>$avg_accuracy LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE accuracy_PG_hits    /accuracy_PG_attempts>=@max AND accuracy_PG_attempts>$avg_accuracy;",$db);
if ($result) {
$myrow = mysql_fetch_array($result);
$best_accuracy_PG= $myrow[0];
}

$result=mysql_query("select raw_name from playerstats ORDER BY rand() LIMIT 1;",$db);
if ($result) {
$myrow = mysql_fetch_array($result);
$best_accuracy_BFG = $myrow[0];
}
//******************************************************************************





//******************************************************************************
//* Weapon Awards - Kills
//******************************************************************************

mysql_query("select @max:=MAX(kills_G/(games+$avg_games))-0.01 FROM playerstats WHERE (games>$avg_games) LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE kills_G/(games+$avg_games)>=@max AND (games>$avg_games);",$db);
if ($result) {
$myrow = mysql_fetch_array($result);
$best_kills_G= $myrow[0];
}

mysql_query("select @max:=MAX(kills_MG/(games+$avg_games))-0.01 FROM playerstats WHERE (games>$avg_games) LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE kills_MG/(games+$avg_games)>=@max AND (games>$avg_games);",$db);
if ($result) {
$myrow = mysql_fetch_array($result);
$best_kills_MG= $myrow[0];
}

mysql_query("select @max:=MAX(kills_SG/(games+$avg_games))-0.01 FROM playerstats WHERE (games>$avg_games) LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE kills_SG/(games+$avg_games)>=@max AND (games>$avg_games);",$db);
if ($result) {
$myrow = mysql_fetch_array($result);
$best_kills_SG= $myrow[0];
}

mysql_query("select @max:=MAX(kills_GL/(games+$avg_games))-0.01 FROM playerstats WHERE (games>$avg_games) LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE kills_GL/(games+$avg_games)>=@max AND (games>$avg_games);",$db);
if ($result) {
$myrow = mysql_fetch_array($result);
$best_kills_GL= $myrow[0];
}

mysql_query("select @max:=MAX(kills_RL/(games+$avg_games))-0.01 FROM playerstats WHERE (games>$avg_games) LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE kills_RL/(games+$avg_games)>=@max AND (games>$avg_games);",$db);
if ($result) {
$myrow = mysql_fetch_array($result);
$best_kills_RL= $myrow[0];
}

mysql_query("select @max:=MAX(kills_LG/(games+$avg_games))-0.01 FROM playerstats WHERE (games>$avg_games) LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE kills_LG/(games+$avg_games)>=@max AND (games>$avg_games);",$db);
if ($result) {
$myrow = mysql_fetch_array($result);
$best_kills_LG= $myrow[0];
}

mysql_query("select @max:=MAX(kills_RG/(games+$avg_games))-0.01 FROM playerstats WHERE (games>$avg_games) LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE kills_RG/(games+$avg_games)>=@max AND (games>$avg_games);",$db);
if ($result) {
$myrow = mysql_fetch_array($result);
$best_kills_RG= $myrow[0];
}

mysql_query("select @max:=MAX(kills_PG/(games+$avg_games))-0.01 FROM playerstats WHERE (games>$avg_games) LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE kills_PG/(games+$avg_games)>=@max AND (games>$avg_games);",$db);
if ($result) {
$myrow = mysql_fetch_array($result);
$best_kills_PG= $myrow[0];
}

mysql_query("select @max:=MAX(kills_BFG/(games+$avg_games))-0.01 FROM playerstats WHERE (games>$avg_games) LIMIT 1;",$db);
$result=mysql_query("select raw_name FROM playerstats WHERE kills_BFG/(games+$avg_games)>=@max AND (games>$avg_games);",$db);
if ($result) {
$myrow = mysql_fetch_array($result);
$best_kills_BFG= $myrow[0];
}

//******************************************************************************






printf("<table BORDER=0 CELLSPACING=0 CELLPADDING=2 WIDTH=100%%>\n");
printf("<tr>");
//******************************************************************************
//* Player Awards Table
//******************************************************************************
printf("<td style=\"border-width: 0\" WIDTH=30%% VALIGN=TOP>");
	printf("<table style=\"border-width: 0\" style=\"border-bottom-width: 0; $style_table\" CELLSPACING=0 CELLPADDING=2 WIDTH=100%%>\n");
	printf("<tr ><td CLASS=\"cellHeading\" style=\"text-align: center\">Player Awards</td></tr>");
	printf("</table>");

	printf("<table style=\"border-width: 0\" style=\"$style_table\" BORDER=1 CELLSPACING=0 CELLPADDING=2 WIDTH=100%%>\n");
	printf("<tr ><td CLASS=\"cell1\" WIDTH=20 valign=top    style=\"text-align: left\"  ><IMG TITLE=\"most valuable player\"    WIDTH=15 HEIGHT=15 SRC=images/awards/player_voodoo.jpg    ></td><td CLASS=\"cell1\" WIDTH=50%%  valign=top style=\"text-align: left\">&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_skill\"          TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A></td><td CLASS=\"cell1\" WIDTH=50%% ><A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_caps\"      TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A>&nbsp;</td><td CLASS=\"cell1\" WIDTH=20><IMG  TITLE=\"best flag capper\"         WIDTH=15 HEIGHT=15 SRC=images/awards/ctf_caps.jpg     ></td></tr>"	,q3_processColors($best_skill)			,q3_processColors($best_caps));
	printf("<tr ><td CLASS=\"cell2\" WIDTH=20 valign=top    style=\"text-align: left\"  ><IMG TITLE=\"deadliest player\"        WIDTH=15 HEIGHT=15 SRC=images/awards/player_combat.jpg    ></td><td CLASS=\"cell2\" WIDTH=50%%  valign=top style=\"text-align: left\">&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_combat\"         TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A></td><td CLASS=\"cell2\" WIDTH=50%% ><A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_escort\"    TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A>&nbsp;</td><td CLASS=\"cell2\" WIDTH=20><IMG  TITLE=\"best flag escort\"         WIDTH=15 HEIGHT=15 SRC=images/awards/ctf_escort.jpg   ></td></tr>"	,q3_processColors($best_combat)			,q3_processColors($best_escort));
	printf("<tr ><td CLASS=\"cell1\" WIDTH=20 valign=top    style=\"text-align: left\"  ><IMG TITLE=\"best killer\"             WIDTH=15 HEIGHT=15 SRC=images/awards/player_kills.jpg     ></td><td CLASS=\"cell1\" WIDTH=50%%  valign=top style=\"text-align: left\">&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_kills\"          TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A></td><td CLASS=\"cell1\" WIDTH=50%% ><A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_holdkills\" TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A>&nbsp;</td><td CLASS=\"cell1\" WIDTH=20><IMG  TITLE=\"best flag holder\"         WIDTH=15 HEIGHT=15 SRC=images/awards/ctf_holder.jpg   ></td></tr>"	,q3_processColors($best_kills)			,q3_processColors($best_holdkills));
	printf("<tr ><td CLASS=\"cell2\" WIDTH=20 valign=top    style=\"text-align: left\"  ><IMG TITLE=\"highest kill streak\"     WIDTH=15 HEIGHT=15 SRC=images/awards/player_bloodlust.jpg ></td><td CLASS=\"cell2\" WIDTH=50%%  valign=top style=\"text-align: left\">&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_kill_streak\"    TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A></td><td CLASS=\"cell2\" WIDTH=50%% ><A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_defends\"   TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A>&nbsp;</td><td CLASS=\"cell2\" WIDTH=20><IMG  TITLE=\"best defender\"            WIDTH=15 HEIGHT=15 SRC=images/awards/ctf_defense.jpg  ></td></tr>"	,q3_processColors($best_kill_streak)	,q3_processColors($best_defends));
	printf("<tr ><td CLASS=\"cell1\" WIDTH=20 valign=top    style=\"text-align: left\"  ><IMG TITLE=\"best overall accuracy\"   WIDTH=15 HEIGHT=15 SRC=images/awards/player_accuracy.jpg  ></td><td CLASS=\"cell1\" WIDTH=50%%  valign=top style=\"text-align: left\">&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_accuracy_total\" TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A></td><td CLASS=\"cell1\" WIDTH=50%% ><A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_assists\"   TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A>&nbsp;</td><td CLASS=\"cell1\" WIDTH=20><IMG  TITLE=\"best assists\"             WIDTH=15 HEIGHT=15 SRC=images/awards/ctf_assists.jpg  ></td></tr>"	,q3_processColors($best_accuracy_total)	,q3_processColors($best_assists));
	printf("<tr ><td CLASS=\"cell2\" WIDTH=20 valign=top    style=\"text-align: left\"  ><IMG TITLE=\"best damage inflicter\"   WIDTH=15 HEIGHT=15 SRC=images/awards/player_damage.jpg    ></td><td CLASS=\"cell2\" WIDTH=50%%  valign=top style=\"text-align: left\">&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_damage_given\"   TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A></td><td CLASS=\"cell2\" WIDTH=50%% ><A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_chaser\"    TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A>&nbsp;</td><td CLASS=\"cell2\" WIDTH=20><IMG  TITLE=\"best flag retriever\"      WIDTH=15 HEIGHT=15 SRC=images/awards/ctf_chaser.jpg   ></td></tr>"	,q3_processColors($best_damage_given)	,q3_processColors($best_chaser));
	printf("<tr ><td CLASS=\"cell1\" WIDTH=20 valign=top    style=\"text-align: left\"  ><IMG TITLE=\"red armor hog\"           WIDTH=15 HEIGHT=15 SRC=images/awards/item_ra.jpg          ></td><td CLASS=\"cell1\" WIDTH=50%%  valign=top style=\"text-align: left\">&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_ra\"             TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A></td><td CLASS=\"cell1\" WIDTH=50%% ><A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_haste\"     TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A>&nbsp;</td><td CLASS=\"cell1\" WIDTH=20><IMG  TITLE=\"haste hog\"                WIDTH=15 HEIGHT=15 SRC=images/awards/item_haste.jpg   ></td></tr>"	,q3_processColors($best_ra)			    ,q3_processColors($best_haste));
	printf("<tr ><td CLASS=\"cell2\" WIDTH=20 valign=top    style=\"text-align: left\"  ><IMG TITLE=\"mega health hog\"         WIDTH=15 HEIGHT=15 SRC=images/awards/item_mega.jpg        ></td><td CLASS=\"cell2\" WIDTH=50%%  valign=top style=\"text-align: left\">&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_mega\"           TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A></td><td CLASS=\"cell2\" WIDTH=50%% ><A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_regen\"     TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A>&nbsp;</td><td CLASS=\"cell2\" WIDTH=20><IMG  TITLE=\"regen hog\"                WIDTH=15 HEIGHT=15 SRC=images/awards/item_regen.jpg   ></td></tr>"	,q3_processColors($best_mega)			,q3_processColors($best_regen));
	printf("<tr ><td CLASS=\"cell1\" WIDTH=20 valign=top    style=\"text-align: left\"  ><IMG TITLE=\"yellow armor hog\"        WIDTH=15 HEIGHT=15 SRC=images/awards/item_ya.jpg          ></td><td CLASS=\"cell1\" WIDTH=50%%  valign=top style=\"text-align: left\">&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_ya\"             TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A></td><td CLASS=\"cell1\" WIDTH=50%% ><A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_quad\"      TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A>&nbsp;</td><td CLASS=\"cell1\" WIDTH=20><IMG  TITLE=\"quad whore\"               WIDTH=15 HEIGHT=15 SRC=images/awards/item_quad.jpg    ></td></tr>"	,q3_processColors($best_ya)	            ,q3_processColors($best_quad));
	printf("</table>");
printf("</td>");
//******************************************************************************

//******************************************************************************
//* Server Info Table
//******************************************************************************
$result=mysql_query("select value FROM miscstats WHERE variable='time' LIMIT 1;",$db);
$myrow = mysql_fetch_array($result);
$time_last_updated = $myrow[0];

$server_line4="last updated on ".$time_last_updated;
printf("<td style=\"border-width: 0\" WIDTH=40%% VALIGN=TOP>");
	printf("<table style=\"border-width: 0\" style=\"border-bottom-width: 0\" CELLSPACING=0 CELLPADDING=2 WIDTH=100%%>\n");
	printf("<tr ><td CLASS=\"cellHeading\" style=\"text-align: center\">$server_name</td></tr>");
	printf("</table>");

	printf("<table BORDER=1 CELLSPACING=0 CELLPADDING=2 WIDTH=100%%>\n");
	printf("<tr ><td CLASS=\"cell1\" style=\"text-align: center\" HEIGHT=105><IMG NAME=LOGO SRC=$server_image></td></tr>");
	printf("<tr ><td CLASS=\"cell2\" style=\"text-align: center\" HEIGHT=21>$server_line1</td></tr>");
	printf("<tr ><td CLASS=\"cell1\" style=\"text-align: center\" HEIGHT=21>$server_line2</td></tr>");
	printf("<tr ><td CLASS=\"cell2\" style=\"text-align: center\" HEIGHT=21>$server_line3</td></tr>");
	printf("<tr ><td CLASS=\"cell1\" style=\"text-align: center\" HEIGHT=21>$server_line4</td></tr>");
	printf("</table>");
printf("</td>");
//******************************************************************************

//******************************************************************************
//* Weapon Awards Table
//******************************************************************************
printf("<td style=\"border-width: 0\" WIDTH=30%% VALIGN=TOP>");
	printf("<table style=\"border-width: 0\" style=\"border-bottom-width: 0; $style_table\" CELLSPACING=0 CELLPADDING=2 WIDTH=100%%>\n");
	printf("<tr ><td CLASS=\"cellHeading\" COLSPAN=2 style=\"text-align: center\">Weapon Awards</td></tr>");
	printf("</table>");

	printf("<table style=\"$style_table\" BORDER=1 CELLSPACING=0 CELLPADDING=2 WIDTH=100%%>\n");
	printf("<tr ><td CLASS=\"cell1\" WIDTH=20 style=\"text-align: left\"><IMG  WIDTH=15 HEIGHT=15 TITLE=\"best telefragger\"                        SRC=images/awards/accuracy_gauntlet.jpg ></td><td CLASS=\"cell1\" WIDTH=50%%  style=\"text-align: left\">&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_kills_TF\"    TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A></td><td CLASS=\"cell1\" WIDTH=50%% >&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_kills_G\" TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A>&nbsp;</td><td CLASS=\"cell1\" WIDTH=20><IMG  WIDTH=15 HEIGHT=15 TITLE=\"best killer with gauntlet\"          SRC=images/awards/carnage_gauntlet.jpg ></td></tr>",q3_processColors($best_kills_TF) ,q3_processColors($best_kills_G));
	printf("<tr ><td CLASS=\"cell2\" WIDTH=20 style=\"text-align: left\"><IMG  WIDTH=15 HEIGHT=15 TITLE=\"best accuracy with machinegun\"           SRC=images/awards/accuracy_machine.jpg  ></td><td CLASS=\"cell2\" WIDTH=50%%  style=\"text-align: left\">&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_accuracy_MG\" TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A></td><td CLASS=\"cell2\" WIDTH=50%% >&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_kills_MG\" TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A>&nbsp;</td><td CLASS=\"cell2\" WIDTH=20><IMG  WIDTH=15 HEIGHT=15 TITLE=\"best killer with machinegun\"       SRC=images/awards/carnage_machine.jpg  ></td></tr>",q3_processColors($best_accuracy_MG),q3_processColors($best_kills_MG));
	printf("<tr ><td CLASS=\"cell1\" WIDTH=20 style=\"text-align: left\"><IMG  WIDTH=15 HEIGHT=15 TITLE=\"best accuracy with shotgun\"              SRC=images/awards/accuracy_shot.jpg     ></td><td CLASS=\"cell1\" WIDTH=50%%  style=\"text-align: left\">&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_accuracy_SG\" TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A></td><td CLASS=\"cell1\" WIDTH=50%% >&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_kills_SG\" TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A>&nbsp;</td><td CLASS=\"cell1\" WIDTH=20><IMG  WIDTH=15 HEIGHT=15 TITLE=\"best killer with shotgun\"          SRC=images/awards/carnage_shot.jpg     ></td></tr>",q3_processColors($best_accuracy_SG),q3_processColors($best_kills_SG));
	printf("<tr ><td CLASS=\"cell2\" WIDTH=20 style=\"text-align: left\"><IMG  WIDTH=15 HEIGHT=15 TITLE=\"best accuracy with grenade launcher\"     SRC=images/awards/accuracy_grenade.jpg  ></td><td CLASS=\"cell2\" WIDTH=50%%  style=\"text-align: left\">&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_accuracy_GL\" TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A></td><td CLASS=\"cell2\" WIDTH=50%% >&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_kills_GL\" TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A>&nbsp;</td><td CLASS=\"cell2\" WIDTH=20><IMG  WIDTH=15 HEIGHT=15 TITLE=\"best killer with grenade launcher\" SRC=images/awards/carnage_grenade.jpg  ></td></tr>",q3_processColors($best_accuracy_GL),q3_processColors($best_kills_GL));
	printf("<tr ><td CLASS=\"cell1\" WIDTH=20 style=\"text-align: left\"><IMG  WIDTH=15 HEIGHT=15 TITLE=\"best accuracy with rocket launcher\"      SRC=images/awards/accuracy_rocket.jpg   ></td><td CLASS=\"cell1\" WIDTH=50%%  style=\"text-align: left\">&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_accuracy_RL\" TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A></td><td CLASS=\"cell1\" WIDTH=50%% >&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_kills_RL\" TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A>&nbsp;</td><td CLASS=\"cell1\" WIDTH=20><IMG  WIDTH=15 HEIGHT=15 TITLE=\"best killer with rocket launcher\"  SRC=images/awards/carnage_rocket.jpg   ></td></tr>",q3_processColors($best_accuracy_RL),q3_processColors($best_kills_RL));
	printf("<tr ><td CLASS=\"cell2\" WIDTH=20 style=\"text-align: left\"><IMG  WIDTH=15 HEIGHT=15 TITLE=\"best accuracy with lightning gun\"        SRC=images/awards/accuracy_lightning.jpg></td><td CLASS=\"cell2\" WIDTH=50%%  style=\"text-align: left\">&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_accuracy_LG\" TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A></td><td CLASS=\"cell2\" WIDTH=50%% >&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_kills_LG\" TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A>&nbsp;</td><td CLASS=\"cell2\" WIDTH=20><IMG  WIDTH=15 HEIGHT=15 TITLE=\"best killer with lightning gun\"    SRC=images/awards/carnage_lightning.jpg></td></tr>",q3_processColors($best_accuracy_LG),q3_processColors($best_kills_LG));
	printf("<tr ><td CLASS=\"cell1\" WIDTH=20 style=\"text-align: left\"><IMG  WIDTH=15 HEIGHT=15 TITLE=\"best accuracy with railgun\"              SRC=images/awards/accuracy_rail.jpg     ></td><td CLASS=\"cell1\" WIDTH=50%%  style=\"text-align: left\">&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_accuracy_RG\" TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A></td><td CLASS=\"cell1\" WIDTH=50%% >&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_kills_RG\" TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A>&nbsp;</td><td CLASS=\"cell1\" WIDTH=20><IMG  WIDTH=15 HEIGHT=15 TITLE=\"best killer with railgun\"          SRC=images/awards/carnage_rail.jpg     ></td></tr>",q3_processColors($best_accuracy_RG),q3_processColors($best_kills_RG));
	printf("<tr ><td CLASS=\"cell2\" WIDTH=20 style=\"text-align: left\"><IMG  WIDTH=15 HEIGHT=15 TITLE=\"best accuracy with plasmagun\"            SRC=images/awards/accuracy_plasma.jpg   ></td><td CLASS=\"cell2\" WIDTH=50%%  style=\"text-align: left\">&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_accuracy_PG\" TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A></td><td CLASS=\"cell2\" WIDTH=50%% >&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_kills_PG\" TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A>&nbsp;</td><td CLASS=\"cell2\" WIDTH=20><IMG  WIDTH=15 HEIGHT=15 TITLE=\"best killer with plasmagun\"        SRC=images/awards/carnage_plasma.jpg   ></td></tr>",q3_processColors($best_accuracy_PG),q3_processColors($best_kills_PG));
	printf("<tr ><td CLASS=\"cell1\" WIDTH=20 style=\"text-align: left\"><IMG  WIDTH=15 HEIGHT=15 TITLE=\"random award!!!??? ;/\"                   SRC=images/awards/accuracy_bfg.jpg      ></td><td CLASS=\"cell1\" WIDTH=50%%  style=\"text-align: left\">&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_accuracy_BFG\" TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A></td><td CLASS=\"cell1\" WIDTH=50%% >&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&raw_name=$best_kills_BFG\" TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A>&nbsp;</td><td CLASS=\"cell1\" WIDTH=20><IMG  WIDTH=15 HEIGHT=15 TITLE=\"best killer with bfg\"              SRC=images/awards/carnage_bfg.jpg    ></td></tr>",q3_processColors($best_accuracy_BFG),q3_processColors($best_kills_BFG));
	printf("</table>");
printf("</td>");
//******************************************************************************
printf("</tr>");
printf("</table><br>");
}







//******************************************************************************
//* Navigation Bar - Top
//******************************************************************************
printf("<table style=\"border-width: 0\" BORDER=0 CELLSPACING=0 CELLPADDING=2 WIDTH=100%%>\n");
printf("<tr>");

printf("<td valign=top style=\"border-width: 0\" align=left>");
printf("<form method=\"post\" action=\"$PHP_SELF?config=$config\">");
printf("<input CLASS=\"cellHeading\" style=\"text-align: center;\" type=\"Submit\" name=\"search_btn\" value=\"&nbsp;search&nbsp;\">&nbsp;");
printf("<input CLASS=\"cellHeading\" style=\"text-align: left;\" size=\"14\" type=\"Text\" name=\"search_txt\">");
printf("<input type=\"hidden\" name=\"sort_by\" value=\"$sort_by\">");
printf("</form>");
printf("</td>");

$last=($total_records-$records_per_page);
if ($last<0)
	$last=0;
printf("<td width=100%% valign=top style=\"border-width: 0\" align=center>");
printf("<table CLASS=\"cellHeading\" style=\"border-width: 1\" CELLSPACING=0 CELLPADDING=2 WIDTH=100%%>\n");
printf("<tr >");
printf("<td CLASS=\"cellHeading\" style=\"text-align: left;   border-width: 0\" >");
printf("&nbsp;[ <A HREF=\"$PHP_SELF?config=$config&start_from=0&sort_by=$sort_by&skip_awards=1\">first</A>");
printf(" | <A HREF=\"$PHP_SELF?config=$config&start_from=$last&sort_by=$sort_by\">last</A> ]");
printf("</td>");
printf("<td CLASS=\"cellHeading\" style=\"text-align: center;   border-width: 0\" >");
printf("[ <A HREF=\"$PHP_SELF?config=$config\">home</A> ]");
printf("</td>");
printf("<td CLASS=\"cellHeading\" style=\"text-align: right;   border-width: 0\" >");
printf("[ <A HREF=\"$PHP_SELF?config=$config&start_from=$prev&sort_by=$sort_by&skip_awards=1\">prev</A> ");
printf("| <A HREF=\"$PHP_SELF?config=$config&start_from=$next&sort_by=$sort_by\">next</A> ]&nbsp;");
printf("</td>");
printf("</tr>");
printf("</table>");
printf("</td>");


printf("<td valign=top style=\"border-width: 0\" >");
printf("<form method=\"post\" action=\"$PHP_SELF?config=$config\">");
printf("<input CLASS=\"cellHeading\" style=\"text-align: right;\" size=\"14\" type=\"Text\" name=\"goto_txt\">&nbsp;");
printf("<input CLASS=\"cellHeading\" style=\"text-align: center;\" type=\"Submit\" name=\"goto_btn\" value=\"&nbsp;go&nbsp;-&nbsp;to&nbsp;\">");
printf("<input type=\"hidden\" name=\"sort_by\" value=\"$sort_by\">");
printf("</form>");
printf("</td>");


printf("</tr>");
printf("</table>");
//******************************************************************************

// MSIE seems to append a <BR> to forms by default, so skip <BR> if browser is MSIE
if (!(strstr($BName,"MSIE") && strstr($BPlatform,"Windows")))
	printf("<BR>");

//******************************************************************************
//* Random Quote
//******************************************************************************
$result=mysql_query("select raw_name,quote from playerstats where LENGTH(quote)>10 AND LENGTH(quote)<50 ORDER BY RAND() LIMIT 1");
$myrow = mysql_fetch_array($result);
printf("<table BORDER=1 style=\"border-bottom-width: 0;\" CELLSPACING=0 CELLPADDING=2 WIDTH=100%%>\n");
	printf("<tr ><td CLASS=\"cellHeading\" style=\"text-align: center\" >random quote</td></tr>");
	printf("<tr ><td CLASS=\"cell1\" style=\"text-align: center\">\" $myrow[1] \" - <A HREF=\"playerstat.php?config=$config&style_table=$style_table&&raw_name=$myrow[0]\" TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">%s</A></td></tr>",q3_processColors($myrow[0]));
printf("</table>");
//******************************************************************************




printf("<BR><table BORDER=0 CELLSPACING=0 CELLPADDING=2 WIDTH=100%%>\n");
printf("<tr>");
//******************************************************************************
//* ClanStats Table
//******************************************************************************
$result = mysql_query("SELECT * from clanstats WHERE stat>0 ORDER BY stat DESC LIMIT $start_from,$records_per_page;",$db);
$myrow = mysql_fetch_array($result);
if (mysql_num_rows($result)>0)
{
printf("<td style=\"border-width: 0\" WIDTH=110 VALIGN=top>");

	printf("<table BORDER=1 style=\"border-bottom-width: 0;\" CELLSPACING=0 CELLPADDING=2 WIDTH=100%%>\n");
	printf("<tr ><td CLASS=\"cellHeading\" style=\"text-align: center\">clan stats</td></tr>");
	printf("</table>");

	printf("<table style=\"$style_table\" BORDER=1 CELLSPACING=0 CELLPADDING=2 WIDTH=100%%>\n");
	//printf("<tr ><td CLASS=\"cell1\" WIDTH=25 valign=top>#</td><td CLASS=\"cell1\" valign=top style=\"text-align: left\">&nbsp;tag</td></tr>");
	$count=1;
	while ($myrow){
		if ($count%2 == 0){
			$cell_class="cell1";
		}
		else{
			$cell_class="cell2";
		}

		printf("<tr CLASS=\"$cell_class\" onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='$cell_class';\"><td CLASS=\"$cell_class\" WIDTH=25 valign=top>%d</td><td CLASS=\"$cell_class\" valign=top style=\"text-align: left\">&nbsp;<A TARGET=\"clanstat\" onclick=\"window.open('','clanstat','resizable=yes,scrollbars=yes,height=540,width=750,screenX=50,screenY=5,left=40,top=2')\" HREF=\"clanstat.php?config=$config&style_table=$style_table&tag=$myrow[0]\">%s</A></td></tr>",$start_from+$count,q3_processColors($myrow[0]));
		$myrow = mysql_fetch_array($result);
		$count++;
	}

	printf("</table>");
printf("</td>");
}
//******************************************************************************



//******************************************************************************
//* MainStats Table
//******************************************************************************
printf("<td style=\"border-width: 0\" VALIGN=top>");

printf("<table BORDER=1 CELLSPACING=0 CELLPADDING=2 WIDTH=100%%>\n");

if (isset($search_txt)||isset($search_btn))
{
	$query_main="SELECT * FROM playerstats WHERE $min_stat AND name LIKE '%$search_txt%' ORDER BY $sort_by_sql DESC LIMIT $start_from,$records_per_page;";
}
else
{
	$query_main="SELECT * FROM playerstats WHERE $min_stat ORDER BY $sort_by_sql DESC LIMIT $start_from,$records_per_page;";
}

$result = mysql_query($query_main,$db);
//echo $query_main;
$myrow = mysql_fetch_array($result);
$count = 0;

while ($myrow)
{

	if ($count%$records_per_page == 0)
	{
		printf("<tr  >");
		printf("<td CLASS=\"cellHeading\">#</td>");
		printf("<td CLASS=\"cellHeading\" style=\"text-align: left\">Name</td>");
		printf("<td CLASS=\"cellHeading\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<A HREF=\"$PHP_SELF?config=$config&start_from=$start_from&sort_by=skill\"                 >Skill :</A></td>");
		printf("<td CLASS=\"cellHeading\"><A HREF=\"$PHP_SELF?config=$config&start_from=$start_from&sort_by=combat\"                            >Combat :</A></td>");
		printf("<td CLASS=\"cellHeading\"><A HREF=\"$PHP_SELF?config=$config&start_from=$start_from&sort_by=frags\"                             >Score</A></td>");
		printf("<td CLASS=\"cellHeading\">&nbsp;&nbsp;&nbsp;&nbsp;<A HREF=\"$PHP_SELF?config=$config&start_from=$start_from&sort_by=kills\"     >Kills</A></td>");
		printf("<td CLASS=\"cellHeading\"><A HREF=\"$PHP_SELF?config=$config&start_from=$start_from&sort_by=deaths\"                            >Deaths</A></td>");
		printf("<td CLASS=\"cellHeading\"><A HREF=\"$PHP_SELF?config=$config&start_from=$start_from&sort_by=suicides\"                          >Suicides</A></td>");
		printf("<td CLASS=\"cellHeading\"><A HREF=\"$PHP_SELF?config=$config&start_from=$start_from&sort_by=efficiency\"                        >Eff. %%</A></td>");
		printf("<td CLASS=\"cellHeading\"><A HREF=\"$PHP_SELF?config=$config&start_from=$start_from&sort_by=games\"                             >Games</A></td>");
		printf("</tr>\n");
	}

	if ($count%2 == 0)
	{
		$cell_class= "cell1";
	}
	else
	{
		$cell_class= "cell2";
	}
	$count++;

	printf("<tr CLASS=\"rowNormal\" onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='rowNormal';\" >");
	printf("<td CLASS=\"$cell_class\">%d</td>", $start_from+$count );

	//if ($myrow["skill"]==0.0)
	//	continue;

	$raw_name = $myrow["raw_name"];
	printf("<td CLASS=\"$cell_class\"><DIV style=\"text-align: left\">");

	printf( "&nbsp;<A HREF=\"playerstat.php?config=$config&style_table=$style_table&&raw_name=%s\" TARGET=\"playerstat\" onclick=\"window.open('','playerstat','resizable=yes,scrollbars=yes,height=430,width=725,screenX=50,screenY=25,left=50,top=25')\">",$raw_name);
	printf("%s",q3_processColors($myrow["raw_name"]));

	printf("</A></DIV></td>");
	printf("<td CLASS=\"$cell_class\">%0.2f</td>", 	$myrow["skill"]/($myrow["games"]+$avg_games));
	printf("<td CLASS=\"$cell_class\">%0.2f</td>", 	$myrow["combat"]/($myrow["games"]+$avg_games));
	printf("<td CLASS=\"$cell_class\">%d</td>", 	$myrow["frags"]);
	printf("<td CLASS=\"$cell_class\">%d</td>", 	$myrow["kills"]);
	printf("<td CLASS=\"$cell_class\">%d</td>", 	$myrow["deaths"]);
	printf("<td CLASS=\"$cell_class\">%d</td>", 	$myrow["suicides"]);
	printf("<td CLASS=\"$cell_class\">%0.2f</td>", 	($myrow["kills"]*100)/(1+$myrow["kills"]+$myrow["deaths"]+$myrow["suicides"]));
	printf("<td CLASS=\"$cell_class\">%d</td>", 	$myrow["games"]);
	printf("</tr>\n");
	$myrow = mysql_fetch_array($result);

}

printf("</table>");
printf("</td>");
//******************************************************************************


//******************************************************************************
//* GameStats Table
//******************************************************************************
$result = mysql_query("SELECT * from gamestats ORDER BY html DESC LIMIT $start_from,$records_per_page;",$db);
$myrow = mysql_fetch_array($result);
if (mysql_num_rows($result)>0)
{
printf("<td style=\"border-width: 0\" WIDTH=110 VALIGN=top>");

	printf("<table BORDER=1 style=\"border-bottom-width: 0;\" CELLSPACING=0 CELLPADDING=2 WIDTH=100%%>\n");
	printf("<tr ><td CLASS=\"cellHeading\" style=\"text-align: center\">game stats</td></tr>");
	printf("</table>");

	printf("<table style=\"$style_table\" BORDER=1 CELLSPACING=0 CELLPADDING=2 WIDTH=100%%>\n");

	$count=0;
	//printf("<tr ><td CLASS=\"cell1\" valign=top style=\"text-align: center\">date , time , game</td></tr>");


	while ($myrow && strstr($myrow[1],"voodoostats")){
		if ($count%2 == 0){
			$cell_class="cell2";
		}
		else{
			$cell_class="cell1";
		}

		$gamename=substr($myrow[1],17,2);
		$gamename.="-";
		$gamename.=substr($myrow[1],20,2);
		$gamename.=" ";
		$gamename.=substr($myrow[1],23,2);
		$gamename.=":";
		$gamename.=substr($myrow[1],26,2);
		$gamename.=" ";
		$gamename.=substr($myrow[1],32,4);


		// alternate game name
		// $gamename=str_replace("_"," ",substr($myrow[1],41,-10));


		printf("<tr CLASS=\"$cell_class\" onMouseOver=\"this.className='rowHighlight';\" onMouseOut=\"this.className='$cell_class';\"><td CLASS=\"$cell_class\" valign=top style=\"text-align: center\">&nbsp;<A TARGET=\"gamestat\" onclick=\"window.open('','gamestat','resizable=yes,scrollbars=yes,height=540,width=750,screenX=20,screenY=5,left=20,top=2')\" HREF=\"$myrow[1]\">$gamename</A></td></tr>");
		$myrow = mysql_fetch_array($result);
		$count++;
	}
	printf("</table>");
printf("</td>");
}
//******************************************************************************
printf("</tr>");
printf("</table><br>");



//******************************************************************************
//* Navigation/Credit Bar - Please leave as it is.
//******************************************************************************
printf("<table CLASS=\"cellHeading\" style=\"border-width: 1\" CELLSPACING=0 CELLPADDING=2 WIDTH=100%%>\n");
printf("<tr >");
printf("<td CLASS=\"cellHeading\" style=\"text-align: left;   border-width: 0\" >&nbsp;[ <A HREF=\"$PHP_SELF?config=$config&start_from=0&sort_by=$sort_by&skip_awards=1\">first</A>&nbsp;|&nbsp;<A HREF=\"$PHP_SELF?config=$config&start_from=$last&sort_by=$sort_by\">last</A> ]</td>");
printf("<td CLASS=\"cellHeading\" style=\"text-align: center; border-width: 0\" >[ additional coding, suggestions by <A HREF=\"mailto:greg@price.org\">phred</A> | additional testing, suggestions by <A HREF=\"mailto:gouki9@yahoo.com\">gouki</A> ]</td>");
printf("<td CLASS=\"cellHeading\" style=\"text-align: right;  border-width: 0\" >[ <A HREF=\"$PHP_SELF?config=$config&start_from=$prev&sort_by=$sort_by&skip_awards=1\">prev</A>&nbsp;|&nbsp;<A HREF=\"$PHP_SELF?config=$config&start_from=$next&sort_by=$sort_by\">next</A> ]&nbsp;</td>");
printf("</tr>");
printf("</table><br>");
//******************************************************************************



//******************************************************************************
//* Credit Bar - Please leave as it is.
//******************************************************************************
printf("<table BORDER=1 style=\"border-bottom-width: 0;\" CELLSPACING=0 CELLPADDING=2 WIDTH=100%%>\n");
printf("<tr ><td COLSPAN=3 CLASS=\"cellHeading\" style=\"text-align: center\" >&nbsp;<A HREF=\"http://www.clanavl.com/voodoo/\">voodoo stats</A> &#169; by <A HREF=\"mailto:myrdd1n@hotmail.com\">myrddin</A> & <A HREF=\"mailto:r3act@hotmail.com\">react</A></td></tr>");
printf("<tr >");
printf("<td WIDTH=33.33%% CLASS=\"cell1\" style=\"text-align: center\"><br><A HREF=\"http://www.orangesmoothie.com\"><img border=0 src=\"images/logo-osp.gif\"><br><br>www.orangesmoothie.com</a><br><br></td>");
printf("<td WIDTH=33.33%% CLASS=\"cell2\" style=\"text-align: center\"><br><A HREF=\"http://www.clanavl.com/voodoo/\"><img border=0 src=\"images/logo-vp.gif\"><br><br>www.clanavl.com/voodoo/</a><br><br></td>");
printf("<td WIDTH=33.33%% CLASS=\"cell1\" style=\"text-align: center\"><br><A HREF=\"http://www.clanavl.com\"><img border=0 src=\"images/logo-avl.gif\"><br><br>www.clanavl.com</a><br><br></td>");
printf("</tr>");
printf("</table><br>");
//******************************************************************************









printf("</body>");
printf("</html>");

?>


